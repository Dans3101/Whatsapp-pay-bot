# WhatsApp Pay Bot

WhatsApp bot with M-Pesa and crypto (Binance) payment integration.
